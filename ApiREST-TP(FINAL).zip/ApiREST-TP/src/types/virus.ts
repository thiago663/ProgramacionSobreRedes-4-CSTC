// DEPRECATED
/* 
import { Document } from "mongoose";

export interface IVirus extends Document{
        sciName : String;
        virusType : String;
        hasVaccine : Boolean;
}
*/